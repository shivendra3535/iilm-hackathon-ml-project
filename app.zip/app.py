from flask import Flask, render_template, request
import pandas as pd
import pickle

app = Flask(__name__)

# Load the data
local_experiences_df = pd.read_csv('local_experiences_indian.csv')

# Data Processing and Analysis
local_experiences_df.dropna(inplace=True)
average_rating_per_category = local_experiences_df.groupby('category')['rating'].mean()
average_price_per_category = local_experiences_df.groupby('category')['price'].mean()

# Function to recommend places
def recommend_places(user_preferences):
    filtered_data = local_experiences_df.copy()
    for preference, value in user_preferences.items():
        if preference == 'price':
            filtered_data = filtered_data[filtered_data['price'] >= value]
        elif preference == 'rating':
            filtered_data = filtered_data[filtered_data['rating'] >= value]
        else:
            filtered_data = filtered_data[filtered_data[preference] == value]

    filtered_data = filtered_data.sort_values(by='rating', ascending=False)
    recommended_names = filtered_data['experience_name'].tolist()
    return filtered_data, recommended_names


# Routes
@app.route('/')
def index():
    return render_template('index3.html', categories=local_experiences_df['category'].unique())

@app.route('/recommend', methods=['POST'])
def recommendation():
    user_preferences = {
        'category': request.form['category'],
        'price': int(request.form['price']),
        'rating': float(request.form['rating'])
    }
    recommended_places = recommend_places(user_preferences)
    return render_template('recommend.html', places=recommended_places)

if __name__ == '__main__':
    app.run(debug=True)
